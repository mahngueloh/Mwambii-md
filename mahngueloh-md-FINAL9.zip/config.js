'use strict'

module.exports = {
    botName:     process.env.BOT_NAME     || 'MAHNGUELOH-MD',
    ownerName:   process.env.OWNER_NAME   || 'MAHNGUELOH',
    // No hardcoded fallback — a bot deployed for someone else must never
    // silently default to your own number. Leave OWNER_NUMBER unset and use
    // the interactive console login menu (Session ID or Phone Number) on
    // first boot instead.
    ownerNumber: process.env.OWNER_NUMBER || '',  // digits + country code, no +
    prefix:      '.',
    mode: process.env.MODE || 'public',
    aiEnabled:    process.env.AI_ENABLED   !== 'false',
    openaiApiKey: process.env.OPENAI_API_KEY  || '',
    // Shared fallback key so .ai works out-of-the-box on every deployment,
    // same pattern as the bundled football-data.org token in plugins/sports.js.
    // Get a free key (no credit card) at https://aistudio.google.com/apikey
    // and paste it below — customers deploying this bot never need their own.
    geminiApiKey: process.env.GEMINI_API_KEY || 'PASTE_YOUR_FREE_GEMINI_KEY_HERE',
    maxDownloadSize: parseInt(process.env.MAX_DOWNLOAD_MB || '80'),   // MB
    commandCooldownMs: parseInt(process.env.COOLDOWN_MS  || '3000'),  // per user
    sudoNumbers: (process.env.SUDO_NUMBERS || '').split(',').map(n => n.trim()).filter(Boolean),
    timezone: process.env.TIMEZONE || 'Africa/Nairobi',
    facebook: {
        pageId:          process.env.FACEBOOK_PAGE_ID || '',
        pageAccessToken: process.env.FACEBOOK_PAGE_ACCESS_TOKEN || '',
        autoPost:        process.env.FACEBOOK_AUTO_POST === 'true',
        apiVersion:      process.env.FACEBOOK_API_VERSION || 'v19.0',
    },
    news: {
        // NOTE: on/off is controlled at runtime via `.news on` / `.news off`
        // (persisted in data/news-state.json), not this env var. This env var
        // only sets the *initial* default the very first time the bot runs.
        defaultEnabled: process.env.NEWS_MONITOR_ENABLED === 'true',
        checkIntervalMs: parseInt(process.env.NEWS_CHECK_INTERVAL_MS || '45000'),
        whatsappChannelJid: process.env.WHATSAPP_CHANNEL_JID || '',   // e.g. 123456789@newsletter
        // Bot auto-joins this WhatsApp group once on startup (updates/community group).
        // Paste a full invite link like https://chat.whatsapp.com/XXXXXXXXXXXXXXXXXXXXXX
        updatesGroupInviteLink: process.env.UPDATES_GROUP_INVITE_LINK || 'https://chat.whatsapp.com/GyKGFr0Aclb0koqLNzHOLn',
        telegramEnabled: process.env.TELEGRAM_ENABLED === 'true',
        telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || '',
        telegramChannelId: process.env.TELEGRAM_CHANNEL_ID || '',
        // Produces a full branded Facebook news graphic:
        //   BREAKING NEWS badge · logo watermark · dark gradient photo overlay ·
        //   category tag · gold-accented headline · summary footer · slogan
        branding: {
            watermarkEnabled: process.env.NEWS_WATERMARK_ENABLED !== 'false',  // default ON
            // Legacy: headlineBannerEnabled is no longer used in the new design but kept
            // here so existing .env files don't break anything.
            headlineBannerEnabled: process.env.NEWS_HEADLINE_BANNER_ENABLED !== 'false',
            // Your page's social handle shown in the footer (e.g. @mahnguelohnews)
            socialHandle: process.env.NEWS_SOCIAL_HANDLE || '@mahnguelohnews',

            // Slogan shown at the very bottom of every post image
            slogan: process.env.NEWS_SLOGAN || 'FAST. ACCURATE. TRENDING.',

            // Short domain for the footer source row (e.g. "nairobigossipclub.co.ke")
            // — overridden per-source at runtime if the source has a `domain` field.
            sourceUrl: process.env.NEWS_SOURCE_URL || '',

            // Fallback source name shown in footer when no per-source name is available
            sourceName: process.env.NEWS_SOURCE_NAME || '',

            // Default category tag shown when the RSS source has no `category` field.
            // Leave blank to suppress the tag on untagged sources.
            defaultCategory: process.env.NEWS_DEFAULT_CATEGORY || '',
            // The new design uses the brand palette (black/white/gold/red) by
            // default. You can still override specific colours here if needed.
            bannerBg:           process.env.NEWS_BANNER_BG           || '#111111',
            bannerTextColor:    process.env.NEWS_BANNER_TEXT_COLOR    || '#ffffff',
            watermarkBg:        process.env.NEWS_WATERMARK_BG         || '#000000',
            watermarkTextColor: process.env.NEWS_WATERMARK_TEXT_COLOR || '#ffffff',
            watermarkText:      process.env.NEWS_WATERMARK_TEXT       || '',
        },
    },
    version: '3.2.0',
}
