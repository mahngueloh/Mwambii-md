'use strict'

// Self-heal on startup: if package.json changed since the last `npm install`
// (new dependency added, or node_modules missing entirely after a fresh
// upload), install automatically instead of crashing on the first require().
try {
    require.resolve('dotenv')
} catch {
    console.log('[ SETUP ] Dependencies missing — running npm install (this can take a minute)...')
    require('child_process').execSync('npm install', { stdio: 'inherit', cwd: __dirname })
    console.log('[ SETUP ] Install complete')
}

require('dotenv').config({ path: require('path').join(__dirname, '.env') })

const fs   = require('fs')
const path = require('path')
const os   = require('os')

// Always ensure a real, editable .env exists — dotenv.config() only READS a
// file, it never creates one, so without this a fresh deploy has nothing to
// edit in the Files tab at all.
;(function ensureEnvFile() {
    const envPath = path.join(__dirname, '.env')
    if (fs.existsSync(envPath)) return
    fs.writeFileSync(envPath, [
        '# Fill in ONE of these two, then restart the bot.',
        '# SESSION_ID: paste one from https://mahngueloh-md-session.onrender.com/',
        'SESSION_ID=',
        '',
        '# PHONE_NUMBER: your WhatsApp number, digits only, with country code, no +',
        '# e.g. 254712345678',
        'PHONE_NUMBER=',
        '',
    ].join('\n'))
    console.log('[ ENV ] Created a blank .env — fill in SESSION_ID or PHONE_NUMBER via the Files tab, then restart')
})()

// Silences noisy libsignal-node debug prints (not routed through the logger)
const NOISY_PATTERNS = [
    /Closing (stale open|open) session/i,
    /Closing session:/i,
    /SessionEntry\s*\{/,
]

// ── Self-healing session recovery ───────────────────────────────────────────
// Repeated "Bad MAC" errors mean specific Signal sessions in ./auth_info are
// corrupted (stale/desynced double-ratchet state for one or more contacts).
// Baileys/libsignal print these directly (bypassing our logger), and on their
// own they never get cleaned up — corrupted sessions just keep failing every
// time that contact messages, which is what caused MAHNGUELOH-MD to go quiet
// for hours after being idle. Instead of just hiding the noise, count these
// and wipe the stale session files automatically so Baileys renegotiates
// fresh ones — no manual restart or file-deletion needed.
let badMacHits = 0
let badMacWindowStart = Date.now()
let recoveryInFlight = false
const BAD_MAC_THRESHOLD    = 3       // this many...
const BAD_MAC_WINDOW_MS    = 60_000  // ...within this window triggers recovery
const RECOVERY_COOLDOWN_MS = 180_000 // don't recover more than once per 3 min
let lastRecoveryAt = 0

function wipeCorruptedSessions() {
    const authDir = path.join(__dirname, 'auth_info')
    let cleared = 0
    try {
        for (const f of fs.readdirSync(authDir)) {
            // session-*.json holds per-contact Signal ratchet state — safe to
            // delete and regenerate. creds.json / app-state-sync files are left
            // untouched so the bot stays paired.
            if (/^session-.*\.json$/.test(f)) {
                try { fs.unlinkSync(path.join(authDir, f)); cleared++ } catch {}
            }
        }
    } catch (e) {
        console.log('[ RECOVER ] Could not read auth_info:', e.message)
    }
    return cleared
}

function maybeRecoverFromBadMac() {
    const now = Date.now()
    if (now - badMacWindowStart > BAD_MAC_WINDOW_MS) {
        badMacWindowStart = now
        badMacHits = 0
    }
    badMacHits++
    if (badMacHits < BAD_MAC_THRESHOLD) return
    if (recoveryInFlight || now - lastRecoveryAt < RECOVERY_COOLDOWN_MS) return

    recoveryInFlight = true
    lastRecoveryAt = now
    badMacHits = 0
    setImmediate(() => {
        const cleared = wipeCorruptedSessions()
        console.log(`[ RECOVER ] ${cleared} corrupted session file(s) cleared after repeated Bad MAC errors — reconnecting...`)
        recoveryInFlight = false
        try { connect() } catch (e) { console.log('[ RECOVER ] reconnect failed:', e.message) }
    })
}

function filterWrite(origWrite) {
    return function (chunk, ...rest) {
        const str = typeof chunk === 'string' ? chunk : chunk?.toString?.('utf8') || ''
        if (/Bad MAC/i.test(str)) maybeRecoverFromBadMac()
        if (NOISY_PATTERNS.some(p => p.test(str))) return true // pretend it was written
        return origWrite.call(this, chunk, ...rest)
    }
}
process.stdout.write = filterWrite(process.stdout.write.bind(process.stdout))
process.stderr.write = filterWrite(process.stderr.write.bind(process.stderr))

const { logEnvDiagnostics } = require('./lib/envCheck')
logEnvDiagnostics()

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    Browsers,
    proto,
    downloadMediaMessage,
} = require('@whiskeysockets/baileys')
const { Boom }  = require('@hapi/boom')
const pino      = require('pino')
const config    = require('./config')
const fmt       = require('./lib/format')
const { getBody, getSender, isOwner } = require('./lib/utils')
const msgStore  = require('./lib/messageStore')
const { printErrorBox } = require('./lib/errorBox')
const { runtimeSettings, STATUS_EMOJIS } = require('./plugins/ownerCmds')
const uncachedNoticeCooldown = new Map()
let lastMsgContext = {}
const { handleMessage }    = require('./handler')
const { handleGroupEvents } = require('./plugins/groups')
const { ensureYtdlp }      = require('./plugins/downloader')
const { initNewsMonitor }  = require('./plugins/newsMonitor')

const log     = pino({ level: 'silent' })
const seen    = new Set()
const rateMap = new Map()
let onlineSent = false, retries = 0, retryTimer = null, sock = null, bannerShown = false, statusReportShown = false, joinedUpdatesGroup = false, lastOpenAt = 0, quickDisconnectStreak = 0

function cleanupSocket() {
    if (!sock) return
    try { sock.ev.removeAllListeners() } catch {}
    try { sock.end(new Error('reconnecting')) } catch {}
    sock = null
}

function dedup(id) {
    if (!id || seen.has(id)) return false
    seen.add(id)
    if (seen.size > 2000) {
        const a = [...seen]; seen.clear(); a.slice(-1000).forEach(i => seen.add(i))
    }
    return true
}

function rateOk(jid) {
    const now = Date.now(), last = rateMap.get(jid) || 0
    if (now - last < 2000) return false
    rateMap.set(jid, now)
    return true
}

function showCode(code, phone) {
    // Format as XXXX-XXXX
    const show = (code || '').replace(/\W/g, '').match(/.{1,4}/g)?.join('-') || code
    console.log('\n' + '━'.repeat(52))
    console.log('  🔑  PAIRING CODE  →  ' + show)
    console.log('━'.repeat(52))
    console.log('\n  Steps to link on WhatsApp:')
    console.log('  1. Open WhatsApp → tap ⋮ (3-dot menu)')
    console.log('  2. Linked Devices → Link a Device')
    console.log('  3. Tap "Link with phone number"')
    console.log('  4. Enter your number: ' + phone)
    console.log('  5. Enter the code above')
    console.log('\n  ⚠  Code expires in ~60 seconds.')
    console.log('     If it says invalid → delete the auth_info')
    console.log('     folder and restart the bot for a fresh code.\n')
}

const MSG_COLORS = ['\x1b[36m', '\x1b[35m', '\x1b[33m', '\x1b[32m', '\x1b[34m']
let msgColorIdx = 0
function printMessageLog(ctx, text) {
    const reset = '\x1b[0m'
    const c1 = MSG_COLORS[msgColorIdx % MSG_COLORS.length]
    const c2 = MSG_COLORS[(msgColorIdx + 1) % MSG_COLORS.length]
    msgColorIdx++
    const bar = '─'.repeat(18)
    const now = new Date()

    console.log(`${c1}${bar}${reset}⌐ ${c2}${config.botName}${reset} ⌐${c1}${bar}${reset}`)
    console.log(`» Sent Time: ${now.toLocaleString('en-US', { weekday: 'long', hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true })}`)
    console.log(`» Date: ${now.toLocaleDateString('en-GB')}`)
    console.log(`» Message Type: ${ctx.messageType}`)
    console.log(`» Sender Name: ${ctx.senderName}`)
    console.log(`» Chat ID: ${ctx.chatId}`)
    console.log(`» Text: ${text}`)
    console.log(`${c2}${bar}${reset}⌐⌐${c1}${bar}${reset}`)
}

function printStatusReport(phone, version) {
    const C = { reset:'\x1b[0m', bold:'\x1b[1m', cyan:'\x1b[36m', green:'\x1b[32m', yellow:'\x1b[33m', red:'\x1b[31m', gray:'\x1b[90m' }
    const on  = `${C.green}✓ ON${C.reset}`
    const off = `${C.red}✗ OFF${C.reset}`
    const ok  = (s) => `${C.green}✓ ${s}${C.reset}`

    let pluginCount = 0
    try { pluginCount = fs.readdirSync(path.join(__dirname, 'plugins')).filter(f => f.endsWith('.js')).length } catch {}

    const maskedPhone = phone ? phone.slice(0, 3) + '*'.repeat(Math.max(0, phone.length - 6)) + phone.slice(-3) : 'unknown'
    const memMb = Math.round(process.memoryUsage().rss / 1024 / 1024)

    const line = (label, value) => console.log(`  ${C.gray}${label.padEnd(10)}${C.reset}: ${value}`)

    console.log(`\n${C.cyan}${C.bold}◆ CONFIGURATION${C.reset}`)
    line('Prefix', config.prefix)
    line('Mode', config.mode === 'public' ? ok('PUBLIC') : `${C.yellow}PRIVATE${C.reset}`)
    line('Owner', config.ownerName)
    line('Plugins', ok(`${pluginCount} loaded`))

    console.log(`\n${C.cyan}${C.bold}◆ RUNTIME${C.reset}`)
    line('Node.js', process.version)
    line('Platform', `${os.platform()} ${os.arch()}`)
    line('Memory', `${memMb} MiB`)
    line('Baileys', version.join('.'))

    console.log(`\n${C.cyan}${C.bold}◆ TOGGLES${C.reset}`)
    const entries = Object.entries(runtimeSettings)
    for (let i = 0; i < entries.length; i += 2) {
        const [k1, v1] = entries[i]
        const [k2, v2] = entries[i + 1] || []
        const left  = `${k1.padEnd(18)}: ${v1 ? on : off}`
        const right = k2 ? `${k2.padEnd(18)}: ${v2 ? on : off}` : ''
        console.log(`  ${left}  ${right}`)
    }

    console.log(`\n${C.cyan}${C.bold}◆ CONNECTION${C.reset}`)
    line('WhatsApp', ok('connected'))
    line('Account', `+${maskedPhone}`)
    console.log('')
}

// ── Session ID restore (from the MAHNGUELOH MD SESSION pairing site) ───────
// Decodes a "MAHNGUELOH~<base64 gzip>" SESSION_ID from .env into ./auth_info
// BEFORE useMultiFileAuthState reads it, so if it's valid, Baileys sees an
// already-registered session and skips pairing-code requests entirely.
// Get a session ID at https://mahngueloh-md-session.onrender.com/
const SESSION_PREFIX = 'MAHNGUELOH~'
function restoreSessionFromEnv() {
    let sessionId = (process.env.SESSION_ID || '').trim()

    // Forgiving fallback: if SESSION_ID itself isn't valid (e.g. someone
    // pasted the whole pairing-site message — label text and all — instead
    // of just the ID), scan the raw .env file for a bare "MAHNGUELOH~..."
    // line anywhere and use that instead. Cheap safety net for an easy
    // copy-paste mistake.
    if (!sessionId.startsWith(SESSION_PREFIX)) {
        try {
            const raw = fs.readFileSync(path.join(__dirname, '.env'), 'utf8')
            const found = raw.split('\n').map(l => l.trim()).find(l => l.startsWith(SESSION_PREFIX))
            if (found) {
                sessionId = found
                console.log('[ SESSION ] Found a session ID elsewhere in .env (not on the SESSION_ID= line) — using it anyway')
            }
        } catch {}
    }

    if (!sessionId) return false
    if (!sessionId.startsWith(SESSION_PREFIX)) {
        console.log('[ SESSION ] SESSION_ID is set but not a valid MAHNGUELOH session (missing prefix) — ignoring')
        return false
    }
    try {
        const zlib = require('zlib')
        const gz     = Buffer.from(sessionId.slice(SESSION_PREFIX.length), 'base64')
        const bundle = JSON.parse(zlib.gunzipSync(gz).toString('utf8'))
        const authDir = path.join(__dirname, 'auth_info')
        fs.mkdirSync(authDir, { recursive: true })
        for (const [file, content] of Object.entries(bundle)) {
            const full = path.join(authDir, file)
            fs.mkdirSync(path.dirname(full), { recursive: true })
            fs.writeFileSync(full, content, 'utf8')
        }
        console.log(`[ SESSION ] Restored ${Object.keys(bundle).length} file(s) from SESSION_ID — skipping pairing code`)
        return true
    } catch (e) {
        console.log('[ SESSION ] Failed to restore SESSION_ID:', e.message)
        return false
    }
}

function printLoginMenu(hasSessionId, hasPhone) {
    const C = { reset: '\x1b[0m', cyan: '\x1b[36m', yellow: '\x1b[33m', green: '\x1b[32m', gray: '\x1b[90m' }
    console.log(`\n${C.cyan}No login configured yet — pick ONE of these${C.reset} :`)
    console.log(`${C.yellow}1.${C.reset} ${hasSessionId ? C.green + '✓' : C.gray + '✗'} Session ID${C.reset}  — get one from ${C.cyan}https://mahngueloh-md-session.onrender.com/${C.reset}, then in the ${C.cyan}Files${C.reset} tab open ${C.cyan}.env${C.reset} and set ${C.cyan}SESSION_ID=${C.reset}<paste it>`)
    console.log(`${C.yellow}2.${C.reset} ${hasPhone ? C.green + '✓' : C.gray + '✗'} Phone Number${C.reset}  — in the ${C.cyan}Files${C.reset} tab open ${C.cyan}.env${C.reset} and set ${C.cyan}PHONE_NUMBER=${C.reset}<your number, digits only, with country code>`)
    console.log(`${C.gray}Then hit ${C.reset}Restart${C.gray} in this panel — this box only reads .env on startup, it does not read what you type here.${C.reset}\n`)
}

function appendEnv(key, value) {
    const envPath = path.join(__dirname, '.env')
    let content = ''
    try { content = fs.readFileSync(envPath, 'utf8') } catch {}
    const lines = content.split('\n').filter(l => l.trim() && !l.startsWith(`${key}=`))
    lines.push(`${key}=${value}`)
    fs.writeFileSync(envPath, lines.join('\n') + '\n')
}

async function connect() {
    if (retryTimer) { clearTimeout(retryTimer); retryTimer = null }
    cleanupSocket()  // tear down any previous socket before making a new one

    const sessionRestored = restoreSessionFromEnv()
    const { state, saveCreds } = await useMultiFileAuthState('./auth_info')

    let version = [2, 3000, 1015920675]
    try {
        const r = await Promise.race([
            fetchLatestBaileysVersion(),
            new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 8000)),
        ])
        version = r.version
    console.log(`[ VER ] Baileys protocol ${version.join('.')}`)
    } catch {
        console.log(`[ VER ] Using fallback Baileys protocol ${version.join('.')}`)
    }

    // Sanitise phone number — digits only, with country code, no +
    let phone = (config.ownerNumber || '').replace(/\D/g, '')
    let needsPairing = !state.creds.registered

    if (!bannerShown) {
        bannerShown = true
        console.log(`[ BOT   ] ${config.botName}`)
        console.log(`[ OWNER ] ${config.ownerName}`)
        console.log(`[ NUM   ] ${phone}`)
        console.log(`[ PREF  ] ${config.prefix}`)
        console.log(`[ AUTH  ] ${needsPairing ? 'Not paired — pairing code required' : 'Paired ✅'}`)
    }

    // This host's console input box does not reach process.stdin (confirmed —
    // typed input here just gets echoed, never delivered to Node), so this is
    // informational only. Nothing to wait for: either .env already has what's
    // needed (checked below) or it doesn't, in which case exit with clear
    // next steps rather than hang on input that can never arrive.
    if (needsPairing && !sessionRestored) {
        printLoginMenu(!!process.env.SESSION_ID, !!(phone && phone.length >= 7))
    }

    if (needsPairing) {
        if (!phone || phone.length < 7) {
            console.error('❌  No SESSION_ID or PHONE_NUMBER configured. Edit .env in the Files tab, then hit Restart.\n')
            process.exit(1)
        }
        console.log('⏳  Waiting for WhatsApp handshake before requesting code...')
        console.log('    (This usually takes 5-10 seconds)\n')
    }

    // ── Socket ────────────────────────────────────────────────────────────────
    // IMPORTANT for pairing code validity:
    //   • browser MUST use Baileys' built-in Browsers helper, not a custom string.
    //   • mobile MUST be false (tells Baileys to use the multi-device Web protocol).
    const sockInstance = makeWASocket({
        version,
        logger: log,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, log),
        },
        browser: Browsers.ubuntu('Chrome'),  // ← must be standard, not custom
        mobile: false,                        // ← must be false for pairing code
        printQRInTerminal: false,             // ← no QR; we use pairing code
        syncFullHistory: false,
        connectTimeoutMs: 60_000,
        keepAliveIntervalMs: 30_000,
        retryRequestDelayMs: 3_000,
        markOnlineOnConnect: false,
        getMessage: async () => undefined,
    })
    sock = sockInstance

    sock.ev.on('creds.update', saveCreds)

    let pairingRequested = false

    sockInstance.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update

        // ── Pairing code ──────────────────────────────────────────────────────
        // The 'qr' field in connection.update signals that WhatsApp has
        // completed the WebSocket/Noise handshake and is waiting for auth.
        // This is the ONLY correct moment to call requestPairingCode().
        if (qr && needsPairing && !pairingRequested) {
            pairingRequested = true
            for (let attempt = 1; attempt <= 3; attempt++) {
                try {
                    console.log(`[ PAIR ] Requesting code (attempt ${attempt}/3)...`)
                    const code = await sockInstance.requestPairingCode(phone)
                    showCode(code, phone)
                    break
                } catch (e) {
                    console.log(`[ PAIR ] Attempt ${attempt} failed: ${e.message}`)
                    if (attempt < 3) {
                        await new Promise(r => setTimeout(r, 5000))
                    } else {
                        console.log('\n💡 Could not get code. Delete auth_info folder and restart.\n')
                    }
                }
            }
        }

        if (connection === 'connecting') {
            console.log('[ CONN ] Connecting to WhatsApp servers...')
        }

        if (connection === 'open') {
            retries = 0
            lastOpenAt = Date.now()
            pairingRequested = false
            console.log('[ CONN ] ✅ Connected')

            if (!statusReportShown) {
                statusReportShown = true
                // Use the actually-connected account (from Baileys itself) rather
                // than the pre-connection `phone` var, which stays blank on the
                // session-ID restore path — this is what really tells us which
                // WhatsApp account the bot is connected as.
                const connectedNum = (sockInstance.user?.id || '').split(':')[0].split('@')[0] || phone
                printStatusReport(connectedNum, version)
            }

            // Auto-join the updates/community group once per boot — best-effort,
            // never blocks startup if the invite is stale/expired/already joined.
            if (!joinedUpdatesGroup && config.updatesGroupInviteLink) {
                joinedUpdatesGroup = true
                setTimeout(async () => {
                    try {
                        const code = config.updatesGroupInviteLink.split('/').pop().split('?')[0]
                        await sockInstance.groupAcceptInvite(code)
                        console.log('[ GROUP ] Joined updates group')
                    } catch (e) {
                        console.log('[ GROUP ] Could not join updates group:', e.message)
                    }
                }, 6000)
            }

            if (runtimeSettings.alwaysonline) {
                try { await sockInstance.sendPresenceUpdate('available') } catch {}
            }

            // Start the news monitor scheduler (idempotent — safe on reconnects)
            try { initNewsMonitor(sockInstance) } catch (e) { console.error('[ NEWS ] Init failed:', e.message) }

            if (!onlineSent) {
                onlineSent = true
                setTimeout(async () => {
                    try {
                        const now = new Date().toLocaleString('en-US', {
                            month: 'numeric', day: 'numeric', year: 'numeric',
                            hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true,
                        })
                        const frame = [
                            `┏━━━━━━✧ CONNECTED ✧━━━━━━━`,
                            `┃✧ Bot: ${config.botName}`,
                            `┃✧ Prefix: [ ${config.prefix} ]`,
                            `┃✧ Owner: ${config.ownerName}`,
                            `┃✧ Platform: 🖥️ Pterodactyl`,
                            `┃✧ Status: online`,
                            `┃✧ Time: ${now}`,
                            `┗━━━━━━━━━━━━━━━━━━━━━━━━━━`,
                            ``,
                            `Type *${config.prefix}menu* to get started`,
                        ].join('\n')
                        // sockInstance.user.id is the bot's real, actually-connected JID —
                        // always correct, unlike `phone` which is blank whenever
                        // the bot connected via a restored SESSION_ID.
                        const selfJid = sockInstance.user?.id || (phone ? phone + '@s.whatsapp.net' : null)
                        if (selfJid) await sockInstance.sendMessage(selfJid, { text: frame })
                    } catch {}
                }, 4000)
            }
        }

        if (connection === 'close') {
            const boom = new Boom(lastDisconnect?.error)
            const statusCode = boom?.output?.statusCode
            const reason = boom?.message || 'unknown'
            console.log(`[ CONN ] Disconnected — code ${statusCode} — ${reason}`)

            if (statusCode === DisconnectReason.loggedOut || statusCode === 401 || statusCode === 403) {
                console.log('[ AUTH ] Logged out — delete auth_info and restart')
                process.exit(1)
            }

            // A restored SESSION_ID that connects then gets immediately kicked,
            // over and over, means WhatsApp's servers are actively rejecting
            // this session — not a transient network blip. Looping forever on
            // a dead session forever is not resilience, it's just wasted CPU
            // with the same result every time. Detect the pattern and stop.
            const openDuration = lastOpenAt ? Date.now() - lastOpenAt : Infinity
            quickDisconnectStreak = openDuration < 10_000 ? quickDisconnectStreak + 1 : 0

            if (quickDisconnectStreak >= 3) {
                console.log('[ AUTH ] This session keeps getting rejected within seconds of connecting, repeatedly.')
                console.log('[ AUTH ] WhatsApp is not accepting it — this is not a network issue, the session itself is invalid/stale.')
                if (sessionRestored) {
                    try {
                        fs.rmSync(path.join(__dirname, 'auth_info'), { recursive: true, force: true })
                        console.log('[ AUTH ] Cleared the dead session files.')
                    } catch {}
                    console.log('[ AUTH ] Get a FRESH Session ID from https://mahngueloh-md-session.onrender.com/ (do not reuse an old one),')
                    console.log('[ AUTH ] or switch to PHONE_NUMBER pairing in .env instead. Then Restart.')
                } else {
                    console.log('[ AUTH ] Delete the auth_info folder via the Files tab and Restart for a fresh pairing code.')
                }
                process.exit(1)
            }

            if (statusCode === DisconnectReason.restartRequired) {
                connect()
                return
            }

            retries = Math.min(retries + 1, 10)
            const delay = retries * 5
            console.log(`[ CONN ] Reconnecting in ${delay}s...`)
            retryTimer = setTimeout(connect, delay * 1000)
        }
    })

    // ── Messages ──────────────────────────────────────────────────────────────
    sockInstance.ev.on('messages.upsert', async ({ messages, type }) => {
        for (const msg of messages) {
            try {
                if (!msg?.message) continue
                if (!dedup(msg.key.id)) continue

                const jid = msg.key.remoteJid || ''

                // ── Anti-delete: catch "delete for everyone" events ──────────
                // A deletion arrives as a normal message.upsert whose payload
                // is a protocolMessage of type REVOKE, pointing at the id of
                // the message that got deleted. The original content is never
                // resent by WhatsApp, so we look it up in our own cache.
                const revokeKey = (type === 'notify' && msg.message?.protocolMessage?.type === proto.Message.ProtocolMessage.Type.REVOKE)
                    ? msg.message.protocolMessage.key
                    : null
                if (revokeKey) {
                    if (runtimeSettings.antidelete) {
                        const cached = msgStore.get(jid, revokeKey.id)
                        try {
                            const ownerJid = `${config.ownerNumber}@s.whatsapp.net`
                            const chatLabel = jid.endsWith('@g.us') ? `group ${jid}` : jid.replace('@s.whatsapp.net', '')
                            if (cached) {
                                const header = `🗑️ *Anti-Delete*\nChat: ${chatLabel}\nBy: @${(cached.senderNum || '')}\nDeleted at: ${new Date().toLocaleString()}`
                                if (cached.mediaBuffer) {
                                    const isAudio = cached.mediaType === 'audio'
                                    await sockInstance.sendMessage(ownerJid, {
                                        [cached.mediaType]: cached.mediaBuffer,
                                        mimetype: cached.mimetype,
                                        ...(isAudio ? {} : { caption: `${header}${cached.text ? `\n\nCaption: ${cached.text}` : ''}` }),
                                        mentions: cached.senderJid ? [cached.senderJid] : [],
                                    })
                                    if (isAudio) {
                                        await sockInstance.sendMessage(ownerJid, { text: header, mentions: cached.senderJid ? [cached.senderJid] : [] })
                                    }
                                } else {
                                    await sockInstance.sendMessage(ownerJid, {
                                        text: `${header}\n\nMessage:\n${cached.text || '_(no text — unsupported or uncached media type)_'}`,
                                        mentions: cached.senderJid ? [cached.senderJid] : [],
                                    })
                                }
                            } else {
                                // Don't spam the owner: an active/busy group can generate many
                                // deletions with nothing cached (e.g. right after a restart), and
                                // a contentless "something was deleted" notice adds little value
                                // repeated dozens of times. Cap it to one per chat per 15 minutes.
                                const now = Date.now()
                                const lastNotified = uncachedNoticeCooldown.get(jid) || 0
                                if (now - lastNotified > 15 * 60 * 1000) {
                                    uncachedNoticeCooldown.set(jid, now)
                                    await sockInstance.sendMessage(ownerJid, {
                                        text: `🗑️ *Anti-Delete*\nChat: ${chatLabel}\nA message was deleted, but it wasn't cached yet (bot may have just restarted) so the original content couldn't be recovered.\n_(further uncached deletions in this chat are suppressed for 15 min to avoid spam)_`,
                                    })
                                }
                            }
                        } catch (e) { console.error('Anti-delete forward error:', e.message) }
                    }
                    continue
                }


                if (jid === 'status@broadcast') {
                    const poster = msg.key.participant || ''
                    if (runtimeSettings.autoviewstatus && poster) {
                        try { await sockInstance.sendReceipt('status@broadcast', poster, [msg.key.id], 'read') } catch {}
                    }
                    if (runtimeSettings.autoreactstatus && poster) {
                        try {
                            const e = STATUS_EMOJIS[Math.floor(Math.random() * STATUS_EMOJIS.length)]
                            await sockInstance.sendMessage(poster, {
                                react: {
                                    text: e,
                                    key: { remoteJid: 'status@broadcast', id: msg.key.id, participant: poster, fromMe: false }
                                }
                            })
                        } catch {}
                    }
                    continue
                }

                // Allow 'notify' (new) and 'append' (received while offline/reconnecting)
                // Reject only 'replace' (edits) and anything else that's not a real message
                if (type !== 'notify' && type !== 'append') continue
                const ks = Object.keys(msg.message || {})
                if (ks.length === 1 && ks[0] === 'reactionMessage') continue

                const botJid = sockInstance.user?.id || ''
                const sender = getSender(msg, botJid)

                lastMsgContext = {
                    messageType: Object.keys(msg.message?.ephemeralMessage?.message || msg.message || {})[0] || 'N/A',
                    senderName:  msg.pushName || 'N/A',
                    chatId:      (sender || jid || '').replace('@s.whatsapp.net', '').replace('@g.us', ''),
                }

                // Real-time visibility into what the bot is actually receiving —
                // a decorative bordered block per message, so a silent/stuck
                // command is obvious in the console instead of a guessing game.
                const preview = (getBody(msg) || `[${lastMsgContext.messageType}]`).slice(0, 100).replace(/\n/g, ' ')
                printMessageLog(lastMsgContext, preview)

                // ── Anti-delete cache ─────────────────────────────────────────
                // Save (almost) every message as it arrives so that if it's
                // later deleted, we have something to forward. Only bother
                // downloading media when it's small — big files aren't worth
                // the extra latency/memory on every single message.
                if (runtimeSettings.antidelete && jid !== 'status@broadcast') {
                    try {
                        const inner = msg.message?.ephemeralMessage?.message || msg.message
                        const mediaType = ['imageMessage', 'videoMessage', 'stickerMessage', 'audioMessage']
                            .find(t => inner?.[t])
                        const text = getBody(msg)
                        let mediaBuffer = null, mimetype = null
                        if (mediaType) {
                            const mediaMsg = inner[mediaType]
                            mimetype = mediaMsg.mimetype
                            const sizeOk = !mediaMsg.fileLength || Number(mediaMsg.fileLength) < 3 * 1024 * 1024
                            if (sizeOk) {
                                try {
                                    mediaBuffer = await downloadMediaMessage(msg, 'buffer', {}, { logger: log, reuploadRequest: sockInstance.updateMediaMessage })
                                } catch { /* couldn't fetch media — still cache the text/caption below */ }
                            }
                        }
                        msgStore.save(jid, msg.key.id, {
                            text,
                            senderJid: sender,
                            senderNum: (sender || '').replace(/\D/g, ''),
                            mediaType: mediaType === 'stickerMessage' ? 'sticker' : mediaType?.replace('Message', ''),
                            mediaBuffer,
                            mimetype,
                        })
                    } catch (e) { /* never let caching break normal message handling */ }
                }

                if (msg.key.fromMe) {
                    const b = getBody(msg)
                    if (!b || !b.startsWith(config.prefix)) continue
                }

                const isGroupMsg = jid.endsWith('@g.us')
                if (!isOwner(sender, botJid, msg.key?.fromMe) && !rateOk(sender)) {
                    if (isGroupMsg) {
                        // Groups: never spam a public "slow down" message — everyone
                        // in the chat sees it and it looks like the bot is broken.
                        // A small reaction gives feedback without cluttering the chat.
                        try {
                            await sockInstance.sendMessage(jid, {
                                react: { text: '⏱️', key: msg.key }
                            })
                        } catch {}
                    } else {
                        // DMs: only the sender sees this, so a text notice is fine.
                        try {
                            await sockInstance.sendMessage(jid, {
                                text: `⏱ Slow down! Wait a moment before sending another command.`
                            }, { quoted: msg })
                        } catch {}
                    }
                    continue
                }

                if (runtimeSettings.autoread) {
                    try { await sockInstance.readMessages([msg.key]) } catch {}
                }
                if (runtimeSettings.autoreact && !msg.key.fromMe && Math.random() < 0.25) {
                    try {
                        const e = STATUS_EMOJIS[Math.floor(Math.random() * STATUS_EMOJIS.length)]
                        await sockInstance.sendMessage(jid, { react: { text: e, key: msg.key } })
                    } catch {}
                }

                const bodyForLog = getBody(msg) || ''
                if (bodyForLog.startsWith(config.prefix)) {
                    const cmdName = bodyForLog.slice(config.prefix.length).trim().split(/\s+/)[0] || ''
                    const senderNum = (sender || '').replace('@s.whatsapp.net', '').replace('@lid', '')
                    const isOwnerFlag = isOwner(sender, botJid, msg.key?.fromMe)
                    console.log(`[ CMD ] ${cmdName} ← ${senderNum}${isOwnerFlag ? ' [OWNER]' : ''}`)
                }
                await handleMessage(sockInstance, msg)
            } catch (e) {
                printErrorBox('Message Handler Error', e, lastMsgContext)
            }
        }
    })

    // ── Group events ──────────────────────────────────────────────────────────
    sockInstance.ev.on('group-participants.update', async ({ id, participants, action }) => {
        try { await handleGroupEvents(sockInstance, id, participants, action) } catch {}
    })

    // ── Calls ─────────────────────────────────────────────────────────────────
    sockInstance.ev.on('call', async calls => {
        for (const call of calls) {
            if (runtimeSettings.anticall && call.status === 'offer') {
                try { await sockInstance.rejectCall(call.id, call.from) } catch {}
                try {
                    const num = (call.from || '').replace('@s.whatsapp.net', '')
                    await sockInstance.sendMessage(`${config.ownerNumber}@s.whatsapp.net`, {
                        text: `📵 *Anti-Call*\nRejected an incoming ${call.isVideo ? 'video' : 'voice'} call from +${num}`,
                    })
                } catch {}
            }
        }
    })
}

// Pre-install yt-dlp in background so social media downloads work on first use.
// Delayed slightly so its output doesn't interleave with the startup banner.
setTimeout(() => ensureYtdlp(), 5000)

connect().catch(e => { printErrorBox('Fatal Error', e, lastMsgContext); process.exit(1) })
process.on('unhandledRejection', e => printErrorBox('Unhandled Rejection', e instanceof Error ? e : new Error(String(e)), lastMsgContext))
process.on('uncaughtException',  e => printErrorBox('Uncaught Exception',  e, lastMsgContext))
