'use strict'
const config = require('../config')
const os     = require('os')
const fs     = require('fs')
const path   = require('path')
const fmt    = require('../lib/format')

function getRam() {
    const t = os.totalmem(), u = t - os.freemem()
    const pct    = Math.round(u / t * 100)
    const filled = Math.round(pct / 10)
    const bar    = '█'.repeat(filled) + '░'.repeat(10 - filled)
    return { pct, usedMB: Math.round(u / 1024 / 1024), totalGB: (t / 1024 / 1024 / 1024).toFixed(1), bar }
}

function getTime() {
    return new Date().toLocaleString('en-KE', {
        timeZone: config.timezone || 'Africa/Nairobi',
        weekday:  'short',
        hour:     '2-digit',
        minute:   '2-digit',
        hour12:   true,
    })
}

// June-X style command-category frame: |==(diamond) `NAME-CMD` (diamond)==|
function frameBox(title, cmds) {
    const body = cmds.filter(Boolean).map(c => `┃➧ ${c}`).join('\n')
    return `┏━━❐◆ \`${title}\` ◆❐\n${body}\n┗❐`
}

// June-X style status frame
function statusFrame(title, fields) {
    const body = fields.filter(Boolean).map(f => `┃✧ ${f}`).join('\n')
    return `┏━━❐✧ ${title} ✧━━━━━━━\n${body}\n┗━━━━━━━━━━━━━━━━━━━━━━━━━━`
}

async function sendMenu(sock, from, sender, msg) {
    const p   = config.prefix
    const ram = getRam()
    const uptime    = process.uptime()
    const uptimeStr = `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m`

    await fmt.react(sock, msg, '⚡')

    const header = statusFrame(config.botName, [
        `User: ${sender ? '@' + sender.replace(/\D/g, '') : 'N/A'}`,
        `Owner: ${config.ownerName}`,
        `Mode: ${(config.mode || 'public').toUpperCase()}`,
        `Prefix: [ ${p} ]`,
        `Version: v${config.version || '3.1.0'}`,
        `Time: ${getTime()}`,
        `Uptime: ${uptimeStr}`,
        `RAM: ${ram.usedMB}MB / ${ram.totalGB}GB [${ram.bar}] ${ram.pct}%`,
    ])

    const dlMenu = frameBox('DOWNLOADS-CMD', [
        'play', 'song', 'song2', 'ytmp3', 'ytmp4', 'yt', 'yta', 'ytv', 'spotify', 'video',
        'tiktok', 'tiktokaudio', 'tkvid', 'tkaudio', 'tt', 'ttaudio',
        'ig', 'insta', 'twitter', 'tweet', 'facebook', 'fbvid', 'mediafire',
        'toaudio', 'toimg', 'tomp3', 'tovideo', 'movie', 'music', 'mp3', 'spdl', 'torrent', 'download', 'dlvo',
    ])

    const grpMenu = frameBox('GROUP-CMD', [
        'kick', 'add', 'ban', 'unban', 'promote', 'demote', 'mute', 'unmute', 'kickall',
        'tagall', 'tagadmin', 'admins', 'hidetag', 'poll', 'members', 'groupid', 'getgrouppp',
        'invite', 'link', 'totalmembers', 'getsettings', 'debugadmin',
        'approve', 'reject', 'open', 'close', 'modestatus',
        'antilink', 'antispam', 'antisticker', 'antibug', 'antivoicenote', 'antiremove',
        'antigroupmention', 'antidelete', 'antiedit', 'antiviewonce',
        'addbadword', 'deletebadword', 'listbadword', 'bancheck',
        'addignorelist', 'delignorelist', 'listignorelist',
        'addcountrycode', 'delcountrycode', 'listcountrycode',
        'welcome', 'goodbye', 'setgroupname', 'setdesc', 'resetlink', 'setppgroup',
        'setcontextlink', 'gcaddprivacy', 'ppprivacy',
    ])

    const aiMenu = frameBox('AI-CMD', [
        'ai', 'ask', 'gpt', 'gemini', 'deepseek',
        'analyze', 'code', 'story', 'recipe', 'summarize', 'teach', 'generate', 'translate',
    ])

    const toolMenu = frameBox('TOOLS-CMD', [
        'sticker', 'toimage', 'toviewonce', 'remini', 'enhance', 'wallpaper', 'vv', 'vv2', 'reveal', 'save',
        'qrcode', 'tinyurl', 'shorten', 'shorturl', 'calculate', 'genpass', 'fancy', 'fliptext',
        'weather', 'define', 'getpp', 'getabout', 'device',
    ])

    const searchMenu = frameBox('SEARCH-CMD', ['lyrics', 'imdb', 'yts', 'gsmarena'])

    const funMenu = frameBox('FUN-CMD', [
        'fact', 'facts', 'joke', 'jokes', 'meme', 'memes', 'quotes', 'trivia', 'truth', 'dare', 'tod',
        'truthordare', 'truthdetector', 'emojimix',
    ])

    const relMenu = frameBox('RELIGION-CMD', ['bible', 'quran'])

    const sportsMenu = frameBox('SPORTS-CMD', [
        'epl', 'eplmatches', 'eplstandings', 'eplscorers', 'eplupcoming',
        'laliga', 'laligamatches', 'laligastandings', 'laligascorers', 'laligaupcoming',
        'bundesliga', 'bundesligamatches', 'bundesligastandings', 'bundesligascorers', 'bundesligaupcoming',
        'seriea', 'serieamatches', 'serieastandings', 'serieascorers', 'serieaupcoming',
        'ligue1', 'ligue1matches', 'ligue1standings', 'ligue1scorers', 'ligue1upcoming',
        'clmatches', 'clstandings', 'clscorers', 'clupcoming',
        'wcmatches', 'wcstandings', 'wcscorers', 'wcupcoming',
        'wrestlingevents', 'wwenews', 'wweschedule',
    ])

    const customMenu = frameBox('CUSTOM-CMD', ['addcmd', 'editcmd', 'delcmd', 'listcmd', 'cmdinfo'])

    // Kali/Linux/pentest tooling (160+ commands) intentionally kept out of the
    // main menu. Full list on request via .kalicmds.
    const kaliMenu = frameBox('KALI-CMD', [
        'kali <tool> [args]  — run any tool by name',
        'kalicmds             — full hidden list',
    ])

    const ownerMenu = frameBox('OWNER-CMD', [
        'mode', 'restart', 'setbotname', 'setownername', 'setownernumber', 'setprefix', 'setbio', 'setprofilepic',
        'alwaysonline', 'autoread', 'anticall', 'autoreact', 'autoviewstatus', 'autoreactstatus', 'chatbot',
        'autobio', 'autoblock', 'autorecord', 'autorecordtyping', 'autotype', 'autosavestatus',
        'block', 'unblock', 'unblockall', 'listblocked', 'addsudo', 'delsudo', 'listsudo',
        'warn', 'resetwarn', 'listwarn', 'lastseen', 'readreceipts',
        'setgoodbye', 'setwelcome', 'delgoodbye', 'delwelcome', 'showgoodbye', 'showwelcome',
        'testgoodbye', 'testwelcome', 'setanticallmsg', 'delanticallmsg', 'showanticallmsg', 'testanticallmsg',
        'setaza', 'resetaza', 'aza', 'statussettings', 'statusdelay',
        'setstickerauthor', 'setstickerpackname', 'setwatermark', 'setstatusemoji',
        'setfont', 'setmenu', 'setmenuimage', 'resetsetting', 'settimezone',
        'news', 'fb', 'wa', 'tg', 'setfb',
        'delete', 'broadcast', 'join', 'leave', 'hostip', 'disk', 'allgroups', 'update', 'tostatus', 'off', 'on', 'resetsessions',
    ])

    const genMenu = frameBox('GENERAL-CMD', [
        'menu', 'help', 'ping', 'pong', 'runtime', 'uptime', 'botstatus', 'botping', 'botdate', 'botuptime',
        'owner', 'repo', 'time', 'userid', 'myid', 'feedback', 'report', 'about', 'bot', 'online', 'status',
        'whoami', 'pfp', 'calc', 'math', 'dict', 'meaning', 'quote', 'summary', 'say', 'source', 'repair',
        'listcmds', 'mycmds', 'react',
    ])

    const footer = `> ${config.botName}\nPowered by ${config.ownerName}`

    const fullText = [
        header, '', dlMenu, grpMenu, aiMenu, toolMenu,
        searchMenu, funMenu, relMenu, sportsMenu,
        customMenu, kaliMenu, ownerMenu, genMenu, footer,
    ].join('\n\n')

    const bannerPath = path.join(__dirname, '../assets/banner.png')
    if (fs.existsSync(bannerPath)) {
        await sock.sendMessage(from, {
            image:   fs.readFileSync(bannerPath),
            caption: fullText,
        }, { quoted: msg })
    } else {
        await sock.sendMessage(from, { text: fullText }, { quoted: msg })
    }
}

module.exports = { sendMenu }
